package prueba;

import java.util.Vector;
import java.math.BigInteger;

import javax.swing.JOptionPane;


public class Agenda {
	static int contUser=0;
	static Contacto[] personas = new Contacto[4];
	//static Vector<Contacto> personas=new Vector<Contacto>();//creamos el vertor personas  
	
	public static void agregar(){//funcion para agregar nuevo contacto
		String nombre;
		String apellido;
		int telefono;
	
		nombre=JOptionPane.showInputDialog("Inrese el Nombre");
		apellido=JOptionPane.showInputDialog("Ingrese el Apellido");
		telefono=Integer.parseInt(JOptionPane.showInputDialog("Ingrese el nro de telefono"));
	
		Contacto temp = new Contacto();
		 
        temp.setNombre(nombre); 
        temp.setApellido(apellido);
        temp.setTelefono(telefono);
        personas[contUser] = temp;
        contUser++;  
	}
	
	public static void listar(){//recorre el vector para mostrar los datos existentes
		
		 String ay="";
		 
	        for(int i=0; i<contUser; i++){
	            ay+="Nombre: "+personas[i].getNombre()+"/n"
	              + "Apellido: "+personas[i].getApellido()+"/n"
	              + "Telefono: "+personas[i].getTelefono()+"/n";        
	        }
	        JOptionPane.showMessageDialog(null, ay);
	}
	
	public static void main(String[] args) {
		int op=0;
		
		String me = null;
		do{

			 try{
				me=JOptionPane.showInputDialog(  "1. Agregar Contacto "+"\n"              
						 						+"2. Listado de Contactos "+"\n"
						 						+"3. Buscar Contacto "+"\n"
						 						+"4. Editar Contacto "+"\n"
						 						+"5. Borrar Contacto "+"\n"
						 						+"6. Borrar Agenda "+"\n"
						 						+"0. Salir");
				 
				 if(me!=null && !me.equals("")){
					 op=Integer.parseInt(me);
					 switch(op){
					 case 1:
						 agregar();
						 break;
					 case 2:
						 listar();
						 break;
					 case 3:
						 //buscar();
						 break;
					 case 4:
						 //editar();
						 break;
					 case 5:
						 //eliminar();
						 break;
					 case 6:
						 //vaciar();
						 break;
					 case 0:
						 
						 break;
					 default:
						 JOptionPane.showMessageDialog(null, "No es un numero valido en el menu!!!");                  
					 }
				 }
				 
			 }catch(Exception e){
				 JOptionPane.showMessageDialog(null, "Ingrese un numero");
			 };
	 
	        }while(op!=0 && !me.equals(""));

	}

}
