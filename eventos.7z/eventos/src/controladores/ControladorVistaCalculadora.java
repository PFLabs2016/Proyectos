package controladores;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import vistas.VistaCalculadora;

public class ControladorVistaCalculadora implements ActionListener{
	
	private VistaCalculadora vista;
	public ControladorVistaCalculadora(VistaCalculadora xvista){
			this.vista=xvista;
	}
	public void actionPerformed(ActionEvent accion) {
		String visor=vista.getTxtPantalla().getText();
		
		if(accion.getSource().equals(vista.getBtn1()))
			vista.getTxtPantalla().setText(visor+"1");
			
		else if(accion.getSource().equals(vista.getBtn2()))
			vista.getTxtPantalla().setText(visor+"2");
			
		else if(accion.getSource().equals(vista.getBtn3()))
			vista.getTxtPantalla().setText(visor+"3");
			
		else if(accion.getSource().equals(vista.getBtn4()))
			vista.getTxtPantalla().setText(visor+"4");
			
		else if(accion.getSource().equals(vista.getBtn5()))
			vista.getTxtPantalla().setText(visor+"5");
			
		else if(accion.getSource().equals(vista.getBtn6()))
			vista.getTxtPantalla().setText(visor+"6");
			
		else if(accion.getSource().equals(vista.getBtn7()))
			vista.getTxtPantalla().setText(visor+"7");
			
		else if(accion.getSource().equals(vista.getBtn8()))
			vista.getTxtPantalla().setText(visor+"8");
			
		else if(accion.getSource().equals(vista.getBtn9()))
			vista.getTxtPantalla().setText(visor+"9");
			
		else if(accion.getSource().equals(vista.getBtn0()))
			vista.getTxtPantalla().setText(visor+"0");
		
		else if(accion.getSource().equals(vista.getBtnMas()))
			vista.getTxtPantalla().setText(visor+"+");
			
		else if(accion.getSource().equals(vista.getBtnMenos()))
			vista.getTxtPantalla().setText(visor+"-");
			
		else if(accion.getSource().equals(vista.getBtnMulti()))
			vista.getTxtPantalla().setText(visor+"*");
			
		else if(accion.getSource().equals(vista.getBtnDiv()))
			vista.getTxtPantalla().setText(visor+"/");
		
		else if(accion.getSource().equals(vista.getBtnPunto()))
			vista.getTxtPantalla().setText(visor+".");
		
		else if(accion.getSource().equals(vista.getBtnC()))
			vista.getTxtPantalla().setText(null);
		
		else if(accion.getSource().equals(vista.getBtnCE()))
			retroceder(visor);
		
		else if(accion.getSource().equals(vista.getBtnIgual()))
			vista.getTxtPantalla().setText(""+calcular(visor));

	}
	
	public void retroceder(String xvisor){
		String p1=String.copyValueOf(xvisor.toCharArray(),(0),
				xvisor.length()-1);
		vista.getTxtPantalla().setText(p1);
	}
	
	public double calcular(String xvisor){
		int v1=0,v2=0;
		double r=0;
		char operador=' ';
		for(int i=0;i<xvisor.length();i++){
			
			if((xvisor.charAt(i)=='+')
				||(xvisor.charAt(i)=='-')
				||(xvisor.charAt(i)=='*')
				||(xvisor.charAt(i)=='/')){
			operador=xvisor.charAt(i);
			v1=Integer.parseInt(String.copyValueOf(
					xvisor.toCharArray(),0,(i)));
			
			v2=Integer.parseInt(String.copyValueOf(
					xvisor.toCharArray(),(i+1),
					xvisor.length()-1-i));
				
			}
		}
		if(operador=='+') r=v1+v2;
		else if(operador=='-') r=v1-v2;
		else if(operador=='*') r=v1*v2;
		else if(operador=='/') r=(double)((double)v1/(double)v2);
		return r;
	}

}
//----------------hasta aqui funciona--------------