package vistas;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;

import controladores.ControladorVistaCalculadora;

public class VistaCalculadora extends JFrame {
	
	private JButton btnRetro,btnCE,btnC,btnRaiz,
					btn7,btn8,btn9,btnDiv,
					btn4,btn5,btn6,btnMulti,
					btn1,btn2,btn3,btnMenos,
					btn0,btnPunto,btnMas,btnIgual;
	private JTextArea txtPantalla;
	
	public VistaCalculadora(){
		//iniciliazar botones
		btnRetro=new JButton("<-");
		btnCE=new JButton("CE");
		btnC=new JButton("C");
		btnRaiz=new JButton("V");
		btn7=new JButton("7");
		btn8=new JButton("8");
		btn9=new JButton("9");
		btnDiv=new JButton("/");
		btn4=new JButton("4");
		btn5=new JButton("5");
		btn6=new JButton("6");
		btnMulti=new JButton("*");
		btn1=new JButton("1");
		btn2=new JButton("2");
		btn3=new JButton("3");
		btnMenos=new JButton("-");
		btn0=new JButton("0");
		btnPunto=new JButton(".");
		btnMas=new JButton("+");
		btnIgual=new JButton("=");
		
		txtPantalla=new JTextArea(4,20);
		txtPantalla.setEditable(false);
		//panel pantalla
		JPanel panelPantalla=new JPanel();
		panelPantalla.setBorder(new TitledBorder("CASIO"));
		panelPantalla.add(txtPantalla);
		
		//panel botones
		JPanel panelBotones=new JPanel();
		GridLayout parrilla=new GridLayout(5, 1);
		panelBotones.setLayout(parrilla);
		parrilla.setHgap(20); //separacion horizontal
		parrilla.setVgap(5);  //separacion vertical
	
		JPanel panelAux;
		
		//linea 1
		panelAux=new JPanel();
		panelAux.add(btnRetro);
		panelAux.add(btnCE);
		panelAux.add(btnC);
		panelAux.add(btnRaiz);
		panelBotones.add(panelAux);
		
		//linea 2
		panelAux=new JPanel();
		panelAux.add(btn7);
		panelAux.add(btn8);
		panelAux.add(btn9);
		panelAux.add(btnDiv);
		panelBotones.add(panelAux);
		
		//linea 3
		panelAux=new JPanel();
		panelAux.add(btn4);
		panelAux.add(btn5);
		panelAux.add(btn6);
		panelAux.add(btnMulti);
		panelBotones.add(panelAux);
		
		//linea 4
		panelAux=new JPanel();
		panelAux.add(btn1);
		panelAux.add(btn2);
		panelAux.add(btn3);
		panelAux.add(btnMenos);
		panelBotones.add(panelAux);
		
		//linea 5
		panelAux=new JPanel();
		panelAux.add(btn0);
		panelAux.add(btnPunto);
		panelAux.add(btnMas);
		panelAux.add(btnIgual);
		panelBotones.add(panelAux);
		
		
		//enlaces------
		ControladorVistaCalculadora eco= new ControladorVistaCalculadora(this);
		btn1.addActionListener(eco);
		btn2.addActionListener(eco);
		btn3.addActionListener(eco);
		btn4.addActionListener(eco);
		btn5.addActionListener(eco);
		btn6.addActionListener(eco);
		btn7.addActionListener(eco);
		btn8.addActionListener(eco);
		btn9.addActionListener(eco);
		btn0.addActionListener(eco);
		btnMas.addActionListener(eco);
		btnMenos.addActionListener(eco);
		btnMulti.addActionListener(eco);
		btnDiv.addActionListener(eco);
		btnPunto.addActionListener(eco);
		btnC.addActionListener(eco);
		btnCE.addActionListener(eco);
		btnIgual.addActionListener(eco);
		
		
		
		
		//ensamblaje
		this.add(panelPantalla,BorderLayout.NORTH);
		this.add(panelBotones,BorderLayout.SOUTH);
		
		//diseno ventana 
		this.setResizable(false);
		this.setTitle("Calculadora Super Cientifica");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.pack();
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}

	public JButton getBtnRetro() {
		return btnRetro;
	}

	public JButton getBtnCE() {
		return btnCE;
	}

	public JButton getBtnC() {
		return btnC;
	}

	public JButton getBtnRaiz() {
		return btnRaiz;
	}

	public JButton getBtn7() {
		return btn7;
	}

	public JButton getBtn8() {
		return btn8;
	}

	public JButton getBtn9() {
		return btn9;
	}

	public JButton getBtnDiv() {
		return btnDiv;
	}

	public JButton getBtn4() {
		return btn4;
	}

	public JButton getBtn5() {
		return btn5;
	}

	public JButton getBtn6() {
		return btn6;
	}

	public JButton getBtnMulti() {
		return btnMulti;
	}

	public JButton getBtn1() {
		return btn1;
	}

	public JButton getBtn2() {
		return btn2;
	}

	public JButton getBtn3() {
		return btn3;
	}

	public JButton getBtnMenos() {
		return btnMenos;
	}

	public JButton getBtn0() {
		return btn0;
	}

	public JButton getBtnPunto() {
		return btnPunto;
	}

	public JButton getBtnMas() {
		return btnMas;
	}

	public JButton getBtnIgual() {
		return btnIgual;
	}

	public JTextArea getTxtPantalla() {
		return txtPantalla;
	}

}
