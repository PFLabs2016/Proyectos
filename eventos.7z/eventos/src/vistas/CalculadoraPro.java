package vistas;

public class CalculadoraPro {

	public static void main(String[] args) {
		new VistaCalculadora();

	}

}
