package ControladoresVistaNumeros;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import int_prueba.VistaNumeros;
import modelos.Numero;

public class ControladoresVistaNumeros implements KeyListener{
	private VistaNumeros vista;
	
	public ControladoresVistaNumeros(VistaNumeros xvista) {
		this.vista=xvista;
	}

	@Override
	public void keyPressed(KeyEvent accion) {
		Pattern patronNumero = Pattern.compile("[^0-9]");
		Matcher validarNumero;
		
		Numero modelo=new Numero();
		if(accion.getSource().equals(vista.getTextValor1())&& (accion.getKeyCode()==KeyEvent.VK_ENTER)){
			
			validarNumero = patronNumero.matcher(vista.getTextValor2().getText());
			
			if(!vista.getTextValor2().getText().isEmpty()&&(!validarNumero.find())){
				modelo.setValor1(Integer.parseInt(vista.getTextValor1().getText()));
			}
		}
		
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
