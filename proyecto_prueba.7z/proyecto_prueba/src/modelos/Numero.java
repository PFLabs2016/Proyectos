package modelos;

public class Numero {
	private int valor1;
	private int valor2;
	public Numero() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Numero(int valor1, int valor2) {
		super();
		this.valor1 = valor1;
		this.valor2 = valor2;
	}
	public int getValor1() {
		return valor1;
	}
	public int getValor2() {
		return valor2;
	}
	public void setValor1(int valor1) {
		this.valor1 = valor1;
	}
	public void setValor2(int valor2) {
		this.valor2 = valor2;
	}
	
	//------------->calculos-----------------
	public boolean primoValor1(){
		int cd=0;
		
		for(int i=2;i<this.getValor1();i++)
			if(this.getValor1()%i==0)cd++;
		
		if(cd==0)return true;
		else return false;
		
	}
	public boolean perfectoValor1(){
		int sd=0;
		
		for(int i=1;i<this.getValor1();i++)
			if(this.getValor1()%i==0)sd+=i;
		
		if(sd==getValor1()) return true;
		else return false;
	}
	public boolean primoValor2(){
		int cd=0;
		
		for(int i=2;i<this.getValor2();i++)
			if(this.getValor2()%i==0)cd++;
		
		if(cd==0)return true;
		else return false;
		
	}
	public boolean perfectoValor2(){
		int sd=0;
		
		for(int i=1;i<this.getValor2();i++)
			if(this.getValor2()%i==0)sd+=i;
		
		if(sd==getValor2()) return true;
		else return false;
	}
	
}
