package int_prueba;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import ControladoresVistaNumeros.ControladoresVistaNumeros;

public class VistaNumeros extends JDialog{
	
	private JTextField textValor1, textValor2, textPrimo1, textPrimo2;
	private JButton btnCerrar, btnVaciar;
	
	public VistaNumeros(){
		setBounds(100,100, 531, 436);
		
		JLabel lblTitulo=new JLabel("Numeros");
		lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo.setForeground(Color.BLUE);
		lblTitulo.setFont(new Font("Tahoma", Font.PLAIN, 14));
		getContentPane().add(lblTitulo, BorderLayout.NORTH);
		
		JPanel panelNumeros = new JPanel();
		getContentPane().add(panelNumeros, BorderLayout.CENTER);
		panelNumeros.setLayout(new GridLayout(2,1,0,0));
		
		JPanel panelLinea1=new JPanel();
		FlowLayout flowLayout = (FlowLayout) panelLinea1.getLayout();
		flowLayout.setAlignment(flowLayout.LEFT);
		panelNumeros.add(panelLinea1);
		
		JLabel labelValor1=new JLabel("valor 1:");
		panelLinea1.add(labelValor1);
		
		textValor1 = new JTextField();
		panelLinea1.add(textValor1);
		textValor1.setColumns(3);
		
		JLabel lblValor2=new JLabel("Valor 2:");
		panelLinea1.add(lblValor2);
		
		textValor2=new JTextField();
		panelLinea1.add(textValor2);
		textValor2.setColumns(3);
		textValor2.setEditable(false);
		
		JPanel panelLinea2 = new JPanel();
		FlowLayout flowLayout_1 = (FlowLayout) panelLinea2.getLayout();
		flowLayout_1.setAlignment(FlowLayout.LEFT);
		panelNumeros.add(panelLinea2);
		
		JLabel lblPrimo1 = new JLabel("Valor 1 Primo");
		lblPrimo1.setHorizontalAlignment(SwingConstants.LEFT);
		panelLinea2.add(lblPrimo1);
		
		textPrimo1=new JTextField();
		panelLinea2.add(textPrimo1);
		textPrimo1.setColumns(5);
		textPrimo1.setEditable(false);
		
		JLabel lblPrimo2=new JLabel("valor 2 Primo");
		panelLinea2.add(lblPrimo2);
		
		textPrimo2=new JTextField();
		panelLinea2.add(textPrimo2);
		textPrimo2.setColumns(5);
		textPrimo2.setEditable(false);
		
		JPanel panelBotones = new JPanel();
		getContentPane().add(panelBotones,BorderLayout.SOUTH);
		
		btnVaciar = new JButton("vaciar");
		panelBotones.add(btnVaciar);
		
		btnCerrar = new JButton("cerrar");
		panelBotones.add(btnCerrar);
		
		ControladoresVistaNumeros eco=new ControladoresVistaNumeros(this);
		textValor1.addKeyListener(eco);
	
	}
	
	public JTextField getTextValor1() {
		return textValor1;
	}

	public JTextField getTextValor2() {
		return textValor2;
	}

	public JTextField getTextPrimo1() {
		return textPrimo1;
	}

	public JTextField getTextPrimo2() {
		return textPrimo2;
	}

	public JButton getBtnCerrar() {
		return btnCerrar;
	}

	public JButton getBtnVaciar() {
		return btnVaciar;
	}

	public static void main(String[] arg){
		
		VistaNumeros dialog = new VistaNumeros();
		dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		dialog.pack();
		dialog.setLocationRelativeTo(null);
		dialog.setVisible(true);
	}

}
