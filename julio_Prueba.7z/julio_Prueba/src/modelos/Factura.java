package modelos;

public class Factura {

	private int cedula;
	private String cliente;
	private String producto;
	private double precio;
	private int cantidad;
	public Factura() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Factura(int cedula, String cliente, String producto, int precio, int cantidad) {
		super();
		this.cedula = cedula;
		this.cliente = cliente;
		this.producto = producto;
		this.precio = precio;
		this.cantidad = cantidad;
	}
	public int getCedula() {
		return cedula;
	}
	public String getCliente() {
		return cliente;
	}
	public String getProducto() {
		return producto;
	}
	public double getPrecio() {
		return precio;
	}
	public int getCantidad() {
		return cantidad;
	}
	public void setCedula(int cedula) {
		this.cedula = cedula;
	}
	public void setCliente(String cliente) {
		this.cliente = cliente;
	}
	public void setProducto(String producto) {
		this.producto = producto;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	
	
	public double getTotalBruto(){
		return (this.getCantidad()*this.getPrecio());
		
	}
	public double getIva(){
		return (getTotalBruto()*0.12);
	}
	
	
	
}
