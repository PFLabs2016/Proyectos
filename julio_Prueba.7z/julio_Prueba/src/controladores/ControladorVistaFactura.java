package controladores;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import modelos.Factura;
import vistas.VistaFactura;

public class ControladorVistaFactura implements KeyListener{
	private VistaFactura vista;
	
	public ControladorVistaFactura(VistaFactura xVista) {
		this.vista=xVista;
	}

	@Override
	public void keyPressed(KeyEvent accion) {
		Pattern patronNumero = Pattern.compile("[^0-9]");
		Matcher validarNumero;
		
		Pattern patronLetras = Pattern.compile("[^A-Za-z]");
		Matcher validarLetras;
		
		Factura modelo=new Factura();
		
		if(accion.getSource().equals(vista.getTextCedula())&&
				(accion.getKeyCode()== KeyEvent.VK_ENTER)){
					
			validarNumero = patronNumero.matcher
							(vista.getTextCedula().getText());
					
			 if(!vista.getTextCedula().getText().isEmpty()&&(!validarNumero.find())){
				modelo.setCedula
				(Integer.parseInt(vista.getTextCedula().getText()));
						
				vista.getTextCliente().setEditable(true);
				vista.getTextCliente().requestFocus();
					  }
		}//fin cedula
		else if(accion.getSource().equals(vista.getTextCliente())&&
				(accion.getKeyCode()== KeyEvent.VK_ENTER)){
			
			validarLetras = patronLetras.matcher
						(vista.getTextCliente().getText());
				
			if(!vista.getTextCliente().getText().isEmpty()&&
						 (!validarLetras.find())){
				modelo.setCliente(vista.getTextCliente().getText());
					 vista.getTextProducto().setEditable(true);
					 vista.getTextProducto().requestFocus();
				 }
		}//fin de cliente 
		else if(accion.getSource().equals(vista.getTextProducto())&&
				(accion.getKeyCode()== KeyEvent.VK_ENTER)){
			
			validarLetras = patronLetras.matcher
						(vista.getTextProducto().getText());
				
			if(!vista.getTextProducto().getText().isEmpty()&&
						 (!validarLetras.find())){
				modelo.setProducto(vista.getTextProducto().getText());
					 vista.getTextPrecio().setEditable(true);
					 vista.getTextPrecio().requestFocus();
				 }
		}//fin de producto
		if(accion.getSource().equals(vista.getTextPrecio())&&
				(accion.getKeyCode()== KeyEvent.VK_ENTER)){
					
			validarNumero = patronNumero.matcher
							(vista.getTextPrecio().getText());
					
			 if(!vista.getTextPrecio().getText().isEmpty()&&(!validarNumero.find())){
				modelo.setPrecio
				(Integer.parseInt(vista.getTextPrecio().getText()));
						
				vista.getTextCantidad().setEditable(true);
				vista.getTextCantidad().requestFocus();
					  }
		}//fin de precio
		if(accion.getSource().equals(vista.getTextCantidad())&&
				(accion.getKeyCode()== KeyEvent.VK_ENTER)){
					
			validarNumero = patronNumero.matcher
							(vista.getTextCantidad().getText());
					
			 if(!vista.getTextCantidad().getText().isEmpty()&&(!validarNumero.find())){
				modelo.setCantidad
				(Integer.parseInt(vista.getTextCantidad().getText()));
				
					  vista.getTextTotalBruto().setText(""+modelo.getTotalBruto());
					  }
		}//fin de precio
		
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
}
