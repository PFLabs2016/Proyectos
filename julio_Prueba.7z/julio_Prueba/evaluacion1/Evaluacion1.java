package evaluacion1;

import java.awt.EventQueue;

import javax.swing.JDialog;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import javax.swing.JTextField;

public class Evaluacion1 extends JDialog {
	private JTextField textCedula;
	private JTextField textCliente;
	private JTextField textProducto;
	private JTextField textPrecio;
	private JTextField textCantidad;
	private JTextField textTotalBruto;
	private JTextField textIva;
	private JTextField textImpuesto;
	private JTextField textTotalNeto;


	/**
	 * Create the dialog.
	 */
	public Evaluacion1() {
	
		
		JLabel lblFacturacion = new JLabel("FACTURACI\u00D3N");
		lblFacturacion.setHorizontalAlignment(SwingConstants.CENTER);
		lblFacturacion.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblFacturacion.setForeground(Color.BLUE);
		getContentPane().add(lblFacturacion, BorderLayout.NORTH);
		
		JPanel panelCampos = new JPanel();
		panelCampos.setBorder(new LineBorder(new Color(0, 0, 0), 4, true));
		getContentPane().add(panelCampos, BorderLayout.CENTER);
		panelCampos.setLayout(new GridLayout(4, 1, 0, 0));
		
		JPanel panelLinea1 = new JPanel();
		FlowLayout flowLayout = (FlowLayout) panelLinea1.getLayout();
		flowLayout.setAlignment(FlowLayout.LEFT);
		panelCampos.add(panelLinea1);
		
		JLabel lblCedula = new JLabel("Cedula o Rif:");
		panelLinea1.add(lblCedula);
		
		textCedula = new JTextField();
		panelLinea1.add(textCedula);
		textCedula.setColumns(10);
		
		JLabel lblCliente = new JLabel("Cliente:");
		panelLinea1.add(lblCliente);
		
		textCliente = new JTextField();
		textCliente.setEditable(false);
		panelLinea1.add(textCliente);
		textCliente.setColumns(30);
		
		JPanel panelLinea2 = new JPanel();
		FlowLayout flowLayout_1 = (FlowLayout) panelLinea2.getLayout();
		flowLayout_1.setAlignment(FlowLayout.LEFT);
		panelCampos.add(panelLinea2);
		
		JLabel lblNewLabel = new JLabel("Producto:");
		panelLinea2.add(lblNewLabel);
		
		textProducto = new JTextField();
		textProducto.setEditable(false);
		panelLinea2.add(textProducto);
		textProducto.setColumns(25);
		
		JLabel lblNewLabel_1 = new JLabel("Precio:");
		panelLinea2.add(lblNewLabel_1);
		
		textPrecio = new JTextField();
		textPrecio.setEditable(false);
		panelLinea2.add(textPrecio);
		textPrecio.setColumns(10);
		
		JLabel lblCantidad = new JLabel("Cantidad:");
		panelLinea2.add(lblCantidad);
		
		textCantidad = new JTextField();
		textCantidad.setEditable(false);
		panelLinea2.add(textCantidad);
		textCantidad.setColumns(10);
		
		JPanel panelLinea3 = new JPanel();
		FlowLayout flowLayout_2 = (FlowLayout) panelLinea3.getLayout();
		flowLayout_2.setAlignment(FlowLayout.LEFT);
		panelCampos.add(panelLinea3);
		
		JLabel lblPrecioBruto = new JLabel("Total Bruto:");
		panelLinea3.add(lblPrecioBruto);
		
		textTotalBruto = new JTextField();
		textTotalBruto.setEditable(false);
		panelLinea3.add(textTotalBruto);
		textTotalBruto.setColumns(10);
		
		JLabel lblIva = new JLabel("Iva:");
		panelLinea3.add(lblIva);
		
		textIva = new JTextField();
		textIva.setEditable(false);
		panelLinea3.add(textIva);
		textIva.setColumns(10);
		
		JLabel lblImpuesto = new JLabel("Impuesto:");
		panelLinea3.add(lblImpuesto);
		
		textImpuesto = new JTextField();
		textImpuesto.setEditable(false);
		panelLinea3.add(textImpuesto);
		textImpuesto.setColumns(10);
		
		JPanel panelLinea4 = new JPanel();
		FlowLayout flowLayout_3 = (FlowLayout) panelLinea4.getLayout();
		flowLayout_3.setAlignment(FlowLayout.RIGHT);
		panelCampos.add(panelLinea4);
		
		JLabel lblNewLabel_2 = new JLabel("Total Neto:");
		panelLinea4.add(lblNewLabel_2);
		
		textTotalNeto = new JTextField();
		textTotalNeto.setEditable(false);
		panelLinea4.add(textTotalNeto);
		textTotalNeto.setColumns(12);

	}
	

	public JTextField getTextCedula() {
		return textCedula;
	}


	public JTextField getTextCliente() {
		return textCliente;
	}


	public JTextField getTextProducto() {
		return textProducto;
	}


	public JTextField getTextPrecio() {
		return textPrecio;
	}


	public JTextField getTextCantidad() {
		return textCantidad;
	}


	public JTextField getTextTotalBruto() {
		return textTotalBruto;
	}


	public JTextField getTextIva() {
		return textIva;
	}


	public JTextField getTextImpuesto() {
		return textImpuesto;
	}


	public JTextField getTextTotalNeto() {
		return textTotalNeto;
	}


	public static void main(String[] args) {
		Evaluacion1 dialog = new Evaluacion1();
		dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		dialog.pack();
		dialog.setLocationRelativeTo(null);
		dialog.setVisible(true);
	}
}
