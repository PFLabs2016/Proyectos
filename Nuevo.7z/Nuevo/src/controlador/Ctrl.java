package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import modelo.Personas;
import vista.Vista;

public class Ctrl implements ActionListener {
	private Vista vista;
	
	private Personas modelo;
	
	public Ctrl(Vista vista)
	{
		this.vista = vista;
		modelo= new Personas();
		
	}

	@Override
	public void actionPerformed(ActionEvent ev) {
		// TODO Auto-generated method stub
		
		if (ev.getActionCommand().equalsIgnoreCase("Guardar"))
		{
			
			modelo.setCedula(Integer.parseInt(vista.getTxtCedula()));
			modelo.setNombres(vista.getTxtNombres());
			vista.limpiar();
			JOptionPane.showMessageDialog(null, "Registro Guardado");
			
			
		}
			
			if (ev.getActionCommand().equalsIgnoreCase("Limpiar"))
			{
				
				vista.limpiar();
				JOptionPane.showMessageDialog(null, "Registro Borrado");
				
				
			}
			
			if (ev.getActionCommand().equalsIgnoreCase("Mostrar"))
			{
				
				vista.setTxtCedula(String.valueOf(modelo.getCedula()));
				vista.setTxtNombres(String.valueOf(modelo.getNombres()));
				
				JOptionPane.showMessageDialog(null, vista.getTxtCedula()+vista.getTxtNombres());
				
			}
			

	}

	

}