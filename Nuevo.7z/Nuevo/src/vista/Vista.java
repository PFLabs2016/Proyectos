package vista;

import java.awt.GridLayout;
import java.awt.Label;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

import controlador.Ctrl;

public class Vista extends JFrame {
	private JTextField txtCedula, txtNombres;
	
	public Vista(){
	
		
		setSize(400, 400);
		setTitle("Registro de Personas");
		
		GridLayout orden = new GridLayout(4,2);
		
		setLayout(orden);
		
		Label lblCedula = new Label("Cedula");
		txtCedula = new JTextField(10);
		
		Label lblNombres= new Label("Nombres");
		txtNombres= new JTextField(20);
		
		JButton btnGuardar = new JButton("Guardar");
		
		JButton btnlimpiar = new JButton("Limpiar");
		
		JButton btnMostrar =  new JButton("Mostrar");
		
	 
		
		
		
		add(lblCedula);
		add(txtCedula);
		add(lblNombres);
		add(txtNombres);
		
		add(btnGuardar);
		
		Ctrl controladora= new Ctrl(this);
		btnGuardar.addActionListener(controladora);
		add(btnlimpiar);
		btnlimpiar.addActionListener(controladora);
		add(btnMostrar);
		btnMostrar.addActionListener(controladora);
		
		setVisible(true);
		pack();
		
		
	}
	
	public String getTxtCedula()
	{
		return  txtCedula.getText();
	}
	
	public void setTxtCedula(String cedula)
	{
		txtCedula.setText(cedula);
	}
	
	public String getTxtNombres()
	{
		return  txtNombres.getText();
	}
	
	public void setTxtNombres(String nombres)
	{
		txtNombres.setText(nombres);
	}
	
	public void limpiar()
	{
		txtCedula.setText("");
		txtNombres.setText("");
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		new Vista(); 
		
	}

}
