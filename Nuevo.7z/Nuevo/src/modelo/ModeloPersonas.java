package modelo;

public class ModeloPersonas {
	private Personas[] per;
	private int cantidadPer;
	
	public ModeloPersonas()
	{
		per = new Personas[100];
		
		
	}
	
}
