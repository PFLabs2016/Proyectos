package modelo;

public class Personas {
	private int cedula;
	private String Nombres;
	
	public Personas() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Personas(int cedula, String nombres) {
		super();
		setCedula(cedula);
		setNombres(nombres);
	}
	public int getCedula() {
		return cedula;
	}
	public void setCedula(int cedula) {
		this.cedula = cedula;
	}
	public String getNombres() {
		return Nombres;
	}
	public void setNombres(String nombres) {
		Nombres = nombres;
	}
	
	
	
	

}